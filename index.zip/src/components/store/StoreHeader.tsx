import { useState } from "react";
import { Search, ShoppingBag, User, Heart, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = ["New Arrivals", "Tops", "Bottoms", "Jackets", "Shorts", "Accessories", "Sale"];

export const StoreHeader = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Promo Banner */}
      <div className="bg-primary text-primary-foreground py-2 text-center text-sm font-medium tracking-wide overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...Array(2)].map((_, i) => (
            <span key={i} className="mx-8">
              Extra 20% Off on Any 2 Items — <span className="underline cursor-pointer font-bold">Shop Now</span>
              <span className="mx-8">•</span>
              Free Summer Set on Orders $200+
              <span className="mx-8">•</span>
              Free Shipping Over $159
            </span>
          ))}
        </div>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16 md:h-20">
          <button onClick={() => setMobileOpen(true)} className="md:hidden p-2 text-foreground">
            <Menu className="w-6 h-6" />
          </button>

          <h1 className="font-display text-3xl md:text-4xl font-bold tracking-tighter text-foreground">
            KIIKIO<span className="text-primary">®</span>
          </h1>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link}
                href="#"
                className={`text-sm font-medium tracking-wide transition-colors hover:text-primary ${
                  link === "Sale" ? "text-primary font-bold" : "text-muted-foreground"
                }`}
              >
                {link.toUpperCase()}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <button className="p-2 text-muted-foreground hover:text-foreground transition-colors">
              <Search className="w-5 h-5" />
            </button>
            <button className="hidden md:block p-2 text-muted-foreground hover:text-foreground transition-colors">
              <Heart className="w-5 h-5" />
            </button>
            <button className="hidden md:block p-2 text-muted-foreground hover:text-foreground transition-colors">
              <User className="w-5 h-5" />
            </button>
            <button className="p-2 text-muted-foreground hover:text-foreground transition-colors relative">
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-primary text-primary-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                0
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "tween", duration: 0.3 }}
            className="fixed inset-0 z-[60] bg-background"
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="font-display text-2xl font-bold">MENU</h2>
              <button onClick={() => setMobileOpen(false)} className="p-2">
                <X className="w-6 h-6" />
              </button>
            </div>
            <nav className="flex flex-col p-6 gap-6">
              {navLinks.map((link) => (
                <a
                  key={link}
                  href="#"
                  className="font-display text-2xl font-medium tracking-wide text-foreground hover:text-primary transition-colors"
                  onClick={() => setMobileOpen(false)}
                >
                  {link.toUpperCase()}
                </a>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
