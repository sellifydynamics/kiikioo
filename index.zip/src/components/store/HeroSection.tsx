import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-main.jpg";

export const HeroSection = () => (
  <section className="relative h-[70vh] md:h-[85vh] overflow-hidden">
    <img
      src={heroImage}
      alt="KIIKIO Spring Collection - Urban streetwear"
      className="absolute inset-0 w-full h-full object-cover"
      width={1920}
      height={1080}
    />
    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

    <div className="relative h-full container flex flex-col justify-end pb-12 md:pb-20">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <p className="text-primary font-bold text-sm md:text-base tracking-[0.3em] mb-3">
          SPRING / SUMMER 2025
        </p>
        <h2 className="font-display text-5xl md:text-8xl font-bold leading-[0.9] mb-4">
          SPRING<br />
          SPECIAL
        </h2>
        <p className="text-2xl md:text-4xl font-display font-light text-muted-foreground mb-6">
          UP TO <span className="text-accent font-bold">70% OFF</span>
        </p>
        <Button size="lg" className="group bg-primary hover:bg-primary/90 text-primary-foreground font-display text-lg tracking-wider px-8 py-6 rounded-none">
          SHOP NOW
          <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
        </Button>
      </motion.div>
    </div>
  </section>
);
