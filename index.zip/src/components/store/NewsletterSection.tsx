import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export const NewsletterSection = () => (
  <section className="py-16 md:py-24 bg-secondary/30">
    <div className="container">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-xl mx-auto text-center"
      >
        <p className="text-primary text-sm font-bold tracking-[0.3em] mb-3">JOIN THE CULTURE</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">
          SHARE <span className="text-gradient">#KIIKIO</span>
        </h2>
        <p className="text-muted-foreground mb-8 text-sm">
          Get featured and earn exclusive discount rewards. Share your KIIKIO look on social media and tag us!
        </p>
        <div className="flex gap-2 max-w-md mx-auto">
          <input
            type="email"
            placeholder="Enter your email"
            className="flex-1 bg-background border border-border px-4 py-3 text-sm rounded-sm focus:outline-none focus:border-primary transition-colors"
          />
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold tracking-wider px-6 rounded-sm">
            SUBSCRIBE
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground mt-3">Get 10% off your first order when you subscribe</p>
      </motion.div>
    </div>
  </section>
);
