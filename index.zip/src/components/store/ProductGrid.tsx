import { motion } from "framer-motion";
import { Heart, ShoppingBag, Eye } from "lucide-react";
import product1 from "@/assets/product-1.jpg";
import product2 from "@/assets/product-2.jpg";
import product3 from "@/assets/product-3.jpg";
import product4 from "@/assets/product-4.jpg";
import product5 from "@/assets/product-5.jpg";
import product6 from "@/assets/product-6.jpg";
import product7 from "@/assets/product-7.jpg";
import product8 from "@/assets/product-8.jpg";

const products = [
  { name: "Washed Oversized Hoodie", price: 89, originalPrice: 129, image: product1, tag: "NEW", collection: "CLOUD" },
  { name: "Utility Cargo Pants", price: 95, originalPrice: 145, image: product2, tag: "BEST SELLER", collection: "UTILITY" },
  { name: "Distressed Denim Shorts", price: 65, originalPrice: 99, image: product3, tag: "-34%", collection: "DENIM" },
  { name: "Patch Bomber Jacket", price: 149, originalPrice: 220, image: product4, tag: "HOT", collection: "JACKETS" },
  { name: "Abstract Graphic Tee", price: 55, originalPrice: 79, image: product5, tag: "NEW", collection: "CLOUD" },
  { name: "Patchwork Cargo Jeans", price: 125, originalPrice: 189, image: product6, tag: "-34%", collection: "DENIM" },
  { name: "Flap Utility Sweatpants", price: 85, originalPrice: 129, image: product7, tag: null, collection: "UTILITY" },
  { name: "Cloud Balloon Shorts", price: 69, originalPrice: 99, image: product8, tag: "NEW", collection: "CLOUD" },
];

const ProductCard = ({ product, index }: { product: typeof products[0]; index: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.08 }}
    className="group cursor-pointer"
  >
    <div className="relative aspect-[4/5] overflow-hidden rounded-sm bg-secondary mb-3">
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        loading="lazy"
        width={640}
        height={800}
      />
      {product.tag && (
        <span className={`absolute top-3 left-3 px-2 py-1 text-[10px] font-bold tracking-wider rounded-sm ${
          product.tag === "NEW" ? "bg-accent text-accent-foreground" :
          product.tag === "HOT" ? "bg-primary text-primary-foreground" :
          product.tag === "BEST SELLER" ? "bg-foreground text-background" :
          "bg-primary text-primary-foreground"
        }`}>
          {product.tag}
        </span>
      )}
      <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <button className="w-8 h-8 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
          <Heart className="w-3.5 h-3.5" />
        </button>
        <button className="w-8 h-8 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
          <Eye className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
        <button className="w-full bg-primary text-primary-foreground py-2.5 text-xs font-bold tracking-wider flex items-center justify-center gap-2 rounded-sm hover:bg-primary/90 transition-colors">
          <ShoppingBag className="w-3.5 h-3.5" />
          ADD TO BAG
        </button>
      </div>
    </div>
    <p className="text-[10px] text-primary font-bold tracking-[0.2em] mb-1">{product.collection}</p>
    <h3 className="text-sm font-medium text-foreground mb-1 line-clamp-1">{product.name}</h3>
    <div className="flex items-center gap-2">
      <span className="text-sm font-bold text-foreground">${product.price}</span>
      <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
    </div>
  </motion.div>
);

export const ProductGrid = () => (
  <section className="py-12 md:py-20">
    <div className="container">
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-primary text-sm font-bold tracking-[0.3em] mb-1">TRENDING NOW</p>
          <h2 className="font-display text-3xl md:text-4xl font-bold">BEST SELLERS</h2>
        </div>
        <a href="#" className="text-sm text-primary font-medium hover:underline">Shop All →</a>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {products.map((product, i) => (
          <ProductCard key={product.name} product={product} index={i} />
        ))}
      </div>
    </div>
  </section>
);
