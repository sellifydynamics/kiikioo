import { Truck, Shield, Headphones, RotateCcw } from "lucide-react";

const features = [
  { icon: Truck, title: "FREE SHIPPING", desc: "On orders over $159" },
  { icon: Shield, title: "SECURE PAYMENT", desc: "100% protected checkout" },
  { icon: Headphones, title: "12/6 SUPPORT", desc: "Contact us anytime" },
  { icon: RotateCcw, title: "EASY RETURNS", desc: "30-day return policy" },
];

export const FeaturesBar = () => (
  <section className="border-y border-border py-8 md:py-12">
    <div className="container">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {features.map((f) => (
          <div key={f.title} className="flex items-center gap-3">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-sm bg-secondary flex items-center justify-center flex-shrink-0">
              <f.icon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs md:text-sm font-bold tracking-wider">{f.title}</p>
              <p className="text-[10px] md:text-xs text-muted-foreground">{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);
