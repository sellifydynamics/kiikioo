import { motion } from "framer-motion";
import categoryJackets from "@/assets/category-jackets.jpg";
import categoryTops from "@/assets/category-tops.jpg";
import categoryAccessories from "@/assets/category-accessories.jpg";

const promos = [
  {
    image: categoryJackets,
    title: "ANY 2 JACKETS",
    subtitle: "20% OFF",
    cta: "Mix & Match",
  },
  {
    image: categoryTops,
    title: "BUY 3 GET",
    subtitle: "4TH FREE",
    cta: "Shop Tops",
  },
  {
    image: categoryAccessories,
    title: "MYSTERY",
    subtitle: "BOX",
    cta: "Discover Now",
  },
];

export const PromoCards = () => (
  <section className="py-12 md:py-20">
    <div className="container">
      <div className="flex items-center justify-between mb-8">
        <h2 className="font-display text-3xl md:text-4xl font-bold">DEALS & DROPS</h2>
        <a href="#" className="text-sm text-primary font-medium hover:underline">View All →</a>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {promos.map((promo, i) => (
          <motion.div
            key={promo.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="relative aspect-[4/5] overflow-hidden rounded-sm cursor-pointer group"
          >
            <img
              src={promo.image}
              alt={promo.title}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              loading="lazy"
              width={800}
              height={1024}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <p className="font-display text-3xl md:text-4xl font-bold leading-tight">{promo.title}</p>
              <p className="font-display text-4xl md:text-5xl font-bold text-accent leading-tight">{promo.subtitle}</p>
              <p className="mt-3 text-sm font-medium text-primary tracking-wider uppercase">{promo.cta} →</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);
