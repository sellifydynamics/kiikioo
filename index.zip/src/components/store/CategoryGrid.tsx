import { motion } from "framer-motion";
import categoryTops from "@/assets/category-tops.jpg";
import categoryBottoms from "@/assets/category-bottoms.jpg";
import categoryJackets from "@/assets/category-jackets.jpg";
import categoryAccessories from "@/assets/category-accessories.jpg";

const categories = [
  { name: "TOPS & TEES", image: categoryTops, count: "48 items" },
  { name: "PANTS & JEANS", image: categoryBottoms, count: "36 items" },
  { name: "JACKETS", image: categoryJackets, count: "24 items" },
  { name: "ACCESSORIES", image: categoryAccessories, count: "18 items" },
];

export const CategoryGrid = () => (
  <section className="py-12 md:py-20 bg-secondary/30">
    <div className="container">
      <div className="text-center mb-10">
        <p className="text-primary text-sm font-bold tracking-[0.3em] mb-2">BROWSE BY</p>
        <h2 className="font-display text-4xl md:text-5xl font-bold">CATEGORIES</h2>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-5">
        {categories.map((cat, i) => (
          <motion.a
            key={cat.name}
            href="#"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="relative aspect-[3/4] overflow-hidden rounded-sm group cursor-pointer"
          >
            <img
              src={cat.image}
              alt={cat.name}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              loading="lazy"
              width={800}
              height={1024}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
            <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
              <h3 className="font-display text-lg md:text-2xl font-bold">{cat.name}</h3>
              <p className="text-xs text-muted-foreground mt-1">{cat.count}</p>
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  </section>
);
