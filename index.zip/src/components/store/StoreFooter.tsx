import { MessageCircle, Play, Globe } from "lucide-react";

const footerLinks = {
  SERVICE: ["Size Chart", "Care Guide", "FAQs", "Contact Us"],
  "ABOUT US": ["Our Story", "Best Selling", "Worry-Free Purchase", "Our Sources"],
  INFORMATION: ["Shipping Policy", "Return/Exchange", "Privacy Policy", "Terms & Conditions"],
};

export const StoreFooter = () => (
  <footer className="bg-secondary/50 border-t border-border pt-12 pb-6">
    <div className="container">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
        <div className="col-span-2 md:col-span-1">
          <h3 className="font-display text-3xl font-bold mb-4">
            KIIKIO<span className="text-primary">®</span>
          </h3>
          <p className="text-sm text-muted-foreground mb-4 max-w-xs">
            Streetwear that speaks. Bold, authentic, unapologetic.
          </p>
          <div className="flex gap-3">
            {[MessageCircle, Play, Globe].map((Icon, i) => (
              <a
                key={i}
                href="#"
                className="w-9 h-9 bg-secondary rounded-sm flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
              >
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>
        {Object.entries(footerLinks).map(([title, links]) => (
          <div key={title}>
            <h4 className="font-display text-sm font-bold tracking-wider mb-4">{title}</h4>
            <ul className="space-y-2.5">
              {links.map((link) => (
                <li key={link}>
                  <a href="#" className="text-xs text-muted-foreground hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-border pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-[10px] text-muted-foreground">© 2025 KIIKIO. All rights reserved.</p>
        <div className="flex items-center gap-4">
          {["Visa", "Mastercard", "PayPal", "Apple Pay"].map((m) => (
            <span key={m} className="text-[10px] text-muted-foreground border border-border px-2 py-1 rounded-sm">{m}</span>
          ))}
        </div>
      </div>
    </div>
  </footer>
);
