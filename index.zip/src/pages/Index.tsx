import { StoreHeader } from "@/components/store/StoreHeader";
import { HeroSection } from "@/components/store/HeroSection";
import { PromoCards } from "@/components/store/PromoCards";
import { CategoryGrid } from "@/components/store/CategoryGrid";
import { ProductGrid } from "@/components/store/ProductGrid";
import { FeaturesBar } from "@/components/store/FeaturesBar";
import { NewsletterSection } from "@/components/store/NewsletterSection";
import { StoreFooter } from "@/components/store/StoreFooter";

const Index = () => (
  <div className="min-h-screen bg-background">
    <StoreHeader />
    <HeroSection />
    <PromoCards />
    <CategoryGrid />
    <ProductGrid />
    <FeaturesBar />
    <NewsletterSection />
    <StoreFooter />
  </div>
);

export default Index;
